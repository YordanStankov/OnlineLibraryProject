﻿namespace FInalProject.ViewModels
{
    public class ReturnBookViewModel
    {
        public string UserId { get; set; }
        public int BookId { get; set; }
    }
}
