﻿namespace FInalProject.ViewModels
{
    public class AddAuthorPortraitViewModel
    {
        public int Id { get; set; }
        public string Picture { get; set; }
    }
}
